<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="assets/css/about.css">
  <title>Document</title>
</head>
<body>
 
  <div class="desktop1">
    <img src="image/about.gif" alt="">
    <h1>ABOUT ME</h1>
    <p> HI!! I’m Sherwin H. Lumakang, 20 yrs. old, I live in Sto. Nino Manolo Fortich Bukidnon.<br/>
    My fathers name is Marlon O. Lumakang, my mothers name is Liezel H. Lumakang. I <br/>
    have one sister named Sherilyn Lumakang.</p>
    <h2>HOBBIES
      <li>Basketball</li>
      <li>Online Games</li>
      <li>Retard Mechanic</li>
    </h2>
    <h3>EDUCATION
      <li>Sto. Nino Elem. School</li>
      <li>Manolo Fortich National Highschool</li>
      <li>Northern Bukidnon State College</li>
    </h3>
    <h4>MOTTO
      <p>"If I can DO it TOMORROW, I will not DO it TODAY"</p>
    </h4>
  </div>
<div id="carouselExampleInterval" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active" data-bs-interval="1000">
      <img src="image/1.jpeg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item" data-bs-interval="1000">
      <img src="image/2.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item" data-bs-interval="1000">
      <img src="image/3.jpeg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item" data-bs-interval="1000">
      <img src="image/4.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item" data-bs-interval="1000">
      <img src="image/5.jpeg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item" data-bs-interval="1000">
      <img src="image/5.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item" data-bs-interval="1000">
      <img src="image/7.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item" data-bs-interval="1000">
      <img src="image/8.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item" data-bs-interval="1000">
      <img src="image/9.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item"data-bs-interval="1000">
      <img src="image/10.jpeg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item" data-bs-interval="1000">
      <img src="image/11.jpeg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item" data-bs-interval="1000">
      <img src="image/12.jpeg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item" data-bs-interval="1000">
      <img src="image/13.jpeg" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
</div>
            <h5>PERSONAL PORTFOLIO</h5>
            <a class="h" onclick="to_dashboard()" >HOME</a>
            <a class="a" onclick="to_about()" >ABOUT ME</a>
            <a class="c" onclick="to_contact()" >CONTACT ME</a>
            <a class="p" onclick="to_projects()" >PROJECTS</a>

      

    <script>
    function to_about(){
    $.post("pages/about me/about_me.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}
function to_contact(){
    $.post("pages/contact me/contact_me.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}
function to_projects(){
    $.post("pages/projects/projects.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}
</script>



  
</body>
</html>