<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/projects.css">
    <title>Document</title>
</head>
<body>
    <div class="desktop1">
        <img src="image/projects.gif" alt="">
    </div>
    <div class="Ellipse1">
    <img class="img" src="image/pic.png" alt="">
  </div>
    <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="image/j1.jpeg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="image/j2.jpeg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="image/j3.jpeg" class="d-block w-100" alt="...">
    </div>
  </div>
</div>
<h1>JAVA MAZE GAME</h1>
<p>JAVA MAZE GAME WAS MY FIRST MAJOR PROGRAMMING PROJECT. THIS GAME WAS CREATED DURING MY FIRST 
YEAR DAYS. THE GAME WAS PRESENTED DURING THE JAVA GAME DEV. FEST AT NBSC. AND I AM VERY THANKFUL THAT<br/>
AS THE CO - PROGRAMMER OF THAT GAME WE
SUCCESSFULLY DEFEND THE GAME AND THE CODE.</p>
<h2>ORDERING SYSTEM</h2>
<p class="MS">IN COLLABORATION WITH THE SENIORS (3rd year),</br>
WE CONCEPTUALIZED TO MAKE A COFFE SHOP ORDERING<br/>
SYSTEM,“DECS COFFEE SHOP”. IT WAS NAMED AFTER OUR<br/>
EACH TEAM NAMES “CODESTRIDE” AND DATA EXPLORERS.</p>
<p class="java">JAVA MINI GAME DEV. FEST PROGRAMMER</p>
<p class="code">CODESTRIDE FRONT END PROGRAMMER</p>
<h5>PERSONAL PORTFOLIO</h5>
            <a class="h" onclick="to_dashboard()" >HOME</a>
            <a class="a" onclick="to_about()" >ABOUT ME</a>
            <a class="c" onclick="to_contact()" >CONTACT ME</a>
            <a class="p" onclick="to_projects()" >PROJECTS</a>

<div id="carouselExampleSlidesOnly1" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="image/s1.png" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="image/s2.png" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="image/s3.png" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="image/s4.png" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="image/s5.png" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="image/s6.png" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="image/s7.png" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="image/s8.png" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="image/s9.png" class="d-block w-100" alt="...">
    </div>
  </div>

  <script>
    function to_about(){
    $.post("pages/about me/about_me.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}
function to_contact(){
    $.post("pages/contact me/contact_me.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}
function to_projects(){
    $.post("pages/projects/projects.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}
</script>


</body>
</html>