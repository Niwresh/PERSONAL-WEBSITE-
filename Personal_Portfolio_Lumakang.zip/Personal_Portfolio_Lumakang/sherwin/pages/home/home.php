<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/home.css">
    <title>HOME</title>
</head>
<body>
    <div class="desktop1">
        <img src="image/home.gif" alt="">
        <div class="Ellipse2">
            <img src="image/profile.png" alt="">
            <h1>HELLO_</h1>
            <h2>I'm a</h2>
            <h3>STUDENT</h3>
            <h4>NORTHERN BUKIDNON STATE COLLEGE</h4>
            <p>SHERWIN H. LUMAKANG</p>
            <p class="course" >BACHELOR OF SCIENCE IN INFORMATION TECHNOLOGY (SECOND YEAR)</p>
            <a class="rec1" href="https://web.facebook.com/MasterSherwiiiiN?mibextid=ZbWKwL&_rdc=1&_rdr">
                <img  src="image/facebook.jpg" alt="">
            </a>
            <a class="rec2" href="https://www.instagram.com/invites/contact/?i=1giakgibmb1z4&utm_content=ji3h71a">
                <img  src="image/insta.jpg" alt="">
            </a>
            <a class="rec3" href="https://www.tiktok.com/@dc_sherwiiin?_t=8hvsZHWpGFN&_r=1">
                <img  src="image/tiktok.jpg" alt="">
            </a>
            <a class="rec4" href="https://x.com/Niwrehs_?t=rhbq1FqUWoh2c9MbIv2hwg&s=07">
                <img src="image/twitter.jpg" alt="">
            </a>
            
            <h5>PERSONAL PORTFOLIO</h5>
            <a class="h" onclick="to_dashboard()" >HOME</a>
            <a class="a" onclick="to_about()" >ABOUT ME</a>
            <a class="c" onclick="to_contact()" >CONTACT ME</a>
            <a class="p" onclick="to_projects()" >PROJECTS</a>

        </div>
    </div>

    <script>
    function to_about(){
    $.post("pages/about me/about_me.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}
function to_contact(){
    $.post("pages/contact me/contact_me.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}
function to_projects(){
    $.post("pages/projects/projects.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}
</script>

</body>
</html>