<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/contact.css">
    <title>Document</title>
</head>
<body>
    <div class="desktop1">
        <img src="image/contact.gif" alt="">
        <div class="Ellipse1">
            <img src="image/piic.png" alt="">
        </div>
        <h1>CONTACT ME</h1>
        <h2>CALL OR TEXT:</h2>
        <p class="num" >09750572101 - TM </br>09855854615 - TNT</p>
        <p class="I" >I am active in Facebook,<br/> 
        Messenger,Tiktok, Instagram <br/> 
        and Gmail. But u can message <br/> 
        any of that soc. med. accounts.<br/>
        MESSAGE ME ANYTIME!!!!</p>
        <p class="subs" >ALSO PLEASE FOLLOW AND SUBSCRIBE TO MY TIKTOK AND YOUTUBE ACCOUNT</p>
        <h3>OR MESSAGE ME IN MY SOCIAL MEDIA ACCOUNTS:</h3>
        <a class="fbook" href="https://web.facebook.com/MasterSherwiiiiN?mibextid=ZbWKwL&_rdc=1&_rdr">
            <img src="image/fb.gif" alt="">
        </a>
        <p class="fb">Sherwin Hicera Lumakang</p>

        <a class="mess" href="https://m.me/MasterSherwiiiiN">
            <img src="image/mess.gif" alt="">
        </a>
        <p class="messenger">@MasterSherwiiiiN</p>

        <a class="ig" href="https://www.instagram.com/invites/contact/?i=1giakgibmb1z4&utm_content=ji3h71a">
            <img src="image/ig.gif" alt="">
        </a>
        <p class="insta">@niwresh_</p>

        <a class="twit" href="https://x.com/Niwrehs_?t=rhbq1FqUWoh2c9MbIv2hwg&s=07">
            <img src="image/twit.gif" alt="">
        </a>
        <p class="twitter">@Niwrehs_</p>

        <a class="tik" href="https://www.tiktok.com/@dc_sherwiiin?_t=8hvsZHWpGFN&_r=1">
            <img src="image/tik.gif" alt="">
        </a>
        <p class="tiktok">@dc_sherwiiin</p>

        <a class="yt" href="https://youtube.com/@sherwiiinplays494?si=OHI5L2C_zMFHktCO">
            <img src="image/yt.gif" alt="">
        </a>
        <p class="youtube">SHERWiiiN Plays</p>

            <h5>PERSONAL PORTFOLIO</h5>
            <a class="h" onclick="to_dashboard()" >HOME</a>
            <a class="a" onclick="to_about()" >ABOUT ME</a>
            <a class="c" onclick="to_contact()" >CONTACT ME</a>
            <a class="p" onclick="to_projects()" >PROJECTS</a>

    </div>

    <script>
    function to_about(){
    $.post("pages/about me/about_me.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}
function to_contact(){
    $.post("pages/contact me/contact_me.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}
function to_projects(){
    $.post("pages/projects/projects.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}
</script>


</body>
</html>