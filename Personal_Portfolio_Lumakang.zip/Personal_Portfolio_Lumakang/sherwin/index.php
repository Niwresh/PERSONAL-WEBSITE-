<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <title>PERSONAL_PORTFOLIO</title>
</head>
<body>
    
    <div id= "pages"></div>
    
   <!-------SCRIPTS------>
    <script src="assets/js/jquery-3.7.1.js"></script>
    <script src="assets/js/global.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    
</body>
</html>